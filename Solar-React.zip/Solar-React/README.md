# Solar React

This is a React project built with Vite for solar-related applications.

## Getting Started

1. Install dependencies: `npm install`
2. Run the development server: `npm run dev`
3. Build for production: `npm run build`

## Features

- Fast development with Vite
- React 18
- Hot module replacement

## License

MIT