import React from 'react';

const MatrixCursor: React.FC = () => {
  return <span className="matrix-cursor" />;
};

export default MatrixCursor;